# Buggy Rush : Turbo Édition — Android WebView wrapper

The original `Buggy_Rush_Offline.html` game is copied unchanged to `app/src/main/assets/index.html`.
The Android app opens that exact file in a fullscreen landscape WebView. A custom Buggy Rush launcher icon is included in all Android mipmap sizes.

## Build
Open this folder in Android Studio and build `app` / `assembleDebug`, or push it to GitHub and let the included Actions workflow build the APK. The APK artifact is named `Buggy-Rush-Turbo-APK`.
