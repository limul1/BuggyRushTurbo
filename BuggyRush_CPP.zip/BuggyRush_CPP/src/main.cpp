#include "raylib.h"
#include "raymath.h"
#include "tracks.h"
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <cstdio>

namespace {
constexpr float PI=3.14159265358979323846f;
float clampf(float v,float lo,float hi){return std::max(lo,std::min(hi,v));}
float wrap01(float x){x=std::fmod(x,1.0f);return x<0?x+1:x;}
struct Car { float u=0, lane=0, speed=0, heading=0, drift=0; Color color=RED; bool player=false; int coins=0; };
struct Pickup {float u,lane; bool taken=false;};
struct TrackSample {Vector3 p,t,n;};
TrackSample sampleTrack(const Track&t,float u){
    float f=wrap01(u)*t.count; int i=(int)f; float a=f-i;
    Vector2 p=t.points[i],q=t.points[(i+1)%t.count];
    Vector2 d=Vector2Normalize(Vector2Subtract(q,p));
    Vector2 n={d.y,-d.x};
    Vector3 pos={(p.x+(q.x-p.x)*a)*1.75f,0,(p.y+(q.y-p.y)*a)*1.75f};
    return {pos,{d.x,0,d.y},{n.x,0,n.y}};
}
Vector3 carPosition(const Track&t,const Car&c){auto s=sampleTrack(t,c.u);return Vector3Add(s.p,Vector3Scale(s.n,c.lane));}
void drawCar(const Track&t,const Car&c){
    auto s=sampleTrack(t,c.u);Vector3 p=carPosition(t,c);float yaw=atan2f(s.t.x,s.t.z)+c.heading;
    Matrix rot=MatrixRotateY(yaw);Vector3 forward={sinf(yaw),0,cosf(yaw)};
    DrawCube({p.x,p.y+.58f,p.z},2.0f,.68f,3.25f,c.color);
    DrawCube({p.x+forward.x*.12f,p.y+1.02f,p.z+forward.z*.12f},1.28f,.58f,1.45f,Color{25,36,49,255});
    for(float x:{-1.02f,1.02f})for(float z:{-1.0f,1.0f}){
        Vector3 off=Vector3Add(Vector3Scale(s.n,x),Vector3Scale(s.t,z));
        DrawCube(Vector3Add({p.x,p.y+.30f,p.z},off),.43f,.5f,.68f,BLACK);
    }
    (void)rot;
}
void drawTrack(const Track&t,Color ground,Color kerb){
    DrawPlane({0,-.38f,0},{900,900},ground);
    for(int i=0;i<t.count;i++){
        auto a=sampleTrack(t,(float)i/t.count),b=sampleTrack(t,(float)(i+1)/t.count);
        Vector3 d=Vector3Subtract(b.p,a.p);float len=Vector3Length(d);Vector3 mid=Vector3Scale(Vector3Add(a.p,b.p),.5f);
        float yaw=atan2f(d.x,d.z);
        DrawCube({mid.x,-.16f,mid.z},len+1.4f,.28f,19.0f,Color{58,61,68,255});
        DrawCube({mid.x,.005f,mid.z},len*.48f,.035f,.18f,Color{235,230,205,255});
        for(float side:{-9.8f,9.8f})DrawCube(Vector3Add(mid,Vector3Scale(a.n,side)),len,.55f,.48f,(i%2)?kerb:WHITE);
        for(float side:{-12.0f,12.0f})DrawCube(Vector3Add(mid,Vector3Scale(a.n,side)),len,.42f,.25f,Color{150,155,160,255});
        (void)yaw;
    }
}
void drawButton(Rectangle r,const char*label,Color c){DrawRectangleRounded(r,.28f,8,Fade(c,.88f));DrawRectangleRoundedLines(r,.28f,8,2,WHITE);int fs=std::min(26,(int)(r.height*.36f));DrawText(label,(int)(r.x+r.width/2-MeasureText(label,fs)/2),(int)(r.y+r.height/2-fs/2),fs,WHITE);}
}

int main(){
    SetConfigFlags(FLAG_MSAA_4X_HINT|FLAG_WINDOW_RESIZABLE);
    InitWindow(1280,720,"Buggy Rush Turbo - C++ natif");SetTargetFPS(60);
    int selectedTrack=0,mode=0;bool inMenu=true,paused=false,finished=false;int lap=1;float raceTime=0,finishTimer=0,previousU=0;
    const Track*track=&TRACKS[selectedTrack];
    Car player;player.color=Color{235,48,55,255};player.player=true;
    Car rivals[5];Color rivalColors[5]={BLUE,GOLD,GREEN,PURPLE,ORANGE};
    auto resetRace=[&](){track=&TRACKS[selectedTrack];player=Car{};player.player=true;player.color=Color{235,48,55,255};lap=1;raceTime=0;finishTimer=0;finished=false;previousU=0;
        for(int i=0;i<5;i++){rivals[i]=Car{};rivals[i].u=wrap01(.018f*(i+1));rivals[i].lane=(i%2?2.5f:-2.5f);rivals[i].color=rivalColors[i];rivals[i].speed=20+i*1.4f;}
    };
    std::vector<Pickup> pickups;for(int i=0;i<22;i++)pickups.push_back({wrap01(.025f+i/22.0f),((i%3)-1)*3.2f,false});
    resetRace();
    Camera3D cam={{0,15,-24},{0,0,0},{0,1,0},55,CAMERA_PERSPECTIVE};
    while(!WindowShouldClose()){
        float dt=std::min(GetFrameTime(),.04f);int sw=GetScreenWidth(),sh=GetScreenHeight();
        Vector2 pointer=GetMousePosition();
        bool touchDown=GetTouchPointCount()>0;
        bool pointerDown=IsMouseButtonDown(MOUSE_BUTTON_LEFT)||touchDown;
        bool click=IsMouseButtonPressed(MOUSE_BUTTON_LEFT)||(touchDown && GetTouchPointCount()==1 && GetTouchPosition(0).x>=0);
        if(touchDown) pointer=GetTouchPosition(0);
        if(inMenu){
            if(click){Rectangle start={sw*.34f,sh*.60f,sw*.32f,62};Rectangle prev={sw*.12f,sh*.43f,70,55},next={sw*.80f,sh*.43f,70,55};
                if(CheckCollisionPointRec(pointer,start)){resetRace();inMenu=false;paused=false;}
                if(CheckCollisionPointRec(pointer,prev))selectedTrack=(selectedTrack+7)%8;
                if(CheckCollisionPointRec(pointer,next))selectedTrack=(selectedTrack+1)%8;
                track=&TRACKS[selectedTrack];
            }
            BeginDrawing();ClearBackground(Color{13,27,48,255});DrawText("BUGGY RUSH",sw/2-MeasureText("BUGGY RUSH",58)/2,sh*.16f,58,WHITE);DrawText("TURBO EDITION  |  VERSION C++ NATIVE",sw/2-210,sh*.27f,20,SKYBLUE);
            DrawText("CHOISIS TON CIRCUIT",sw/2-130,sh*.36f,22,LIGHTGRAY);drawButton({sw*.12f,sh*.43f,70,55},"<",DARKBLUE);drawButton({sw*.80f,sh*.43f,70,55},">",DARKBLUE);
            DrawText(TextFormat("%d / 8",selectedTrack+1),sw/2-45,sh*.45f,28,GOLD);DrawText(track->name,sw/2-MeasureText(track->name,30)/2,sh*.52f,30,WHITE);
            drawButton({sw*.34f,sh*.60f,sw*.32f,62},"JOUER",Color{210,45,55,255});DrawText("Course rapide  -  5 adversaires IA  -  commandes tactiles",sw/2-270,sh*.76f,18,LIGHTGRAY);EndDrawing();continue;
        }
        if(IsKeyPressed(KEY_ESCAPE)||IsKeyPressed(KEY_P))paused=!paused;
        if(!paused&&!finished){
            raceTime+=dt;
            float steer=(IsKeyDown(KEY_RIGHT)||IsKeyDown(KEY_D)?1.0f:0.0f)-(IsKeyDown(KEY_LEFT)||IsKeyDown(KEY_A)?1.0f:0.0f);
            bool gas=IsKeyDown(KEY_UP)||IsKeyDown(KEY_W),brake=IsKeyDown(KEY_DOWN)||IsKeyDown(KEY_S),turbo=IsKeyDown(KEY_SPACE),drift=IsKeyDown(KEY_LEFT_SHIFT);
            // Touch zones: left/right steering, right-bottom throttle, right-upper brake, center-right turbo.
            if(pointerDown){
                if(pointer.y>sh*.56f&&pointer.x<sw*.28f)steer=-1;
                else if(pointer.y>sh*.56f&&pointer.x<sw*.48f)steer=1;
                else if(pointer.x>sw*.72f&&pointer.y>sh*.55f)gas=true;
                else if(pointer.x>sw*.72f&&pointer.y<=sh*.55f)brake=true;
                else if(pointer.x>sw*.52f&&pointer.x<sw*.72f)turbo=true;
            }
            float accel=gas?31.0f:0.0f;float braking=brake?48.0f:0.0f;
            player.speed+=(accel-braking-player.speed*(drift?0.65f:1.05f))*dt;
            player.speed=clampf(player.speed,0,turbo?48.0f:36.0f);
            player.lane+=steer*(3.0f+player.speed*.15f)*dt;player.lane=clampf(player.lane,-7.0f,7.0f);
            player.drift=drift?1.0f:0.0f;player.heading=clampf(player.heading+steer*dt*(.8f+player.speed*.018f),-.55f,.55f);
            float trackLen=0;for(int i=0;i<track->count;i++)trackLen+=Vector3Distance(sampleTrack(*track,(float)i/track->count).p,sampleTrack(*track,(float)(i+1)/track->count).p);
            previousU=player.u;player.u=wrap01(player.u+(player.speed*dt)/trackLen);
            // Rivals follow the racing line at different speeds, with gentle lane changes.
            for(int i=0;i<5;i++){rivals[i].u=wrap01(rivals[i].u+(rivals[i].speed*dt)/trackLen);rivals[i].lane=sinf((float)GetTime()*.7f+i)*2.0f;}
            Vector3 pp=carPosition(*track,player);
            for(auto &r:rivals){Vector3 rp=carPosition(*track,r);if(Vector3Distance(pp,rp)<2.8f){player.speed*=.94f;r.speed*=.97f;}}
            for(auto &p:pickups)if(!p.taken){Car temp;temp.u=p.u;temp.lane=p.lane;if(Vector3Distance(pp,carPosition(*track,temp))<2.5f){p.taken=true;player.coins++;player.speed=std::min(player.speed+2.5f,42.0f);}}
            if(previousU>.97f&&player.u<.03f&&raceTime>5.0f)lap++;
            if(lap>3){finished=true;finishTimer=0;}
        } else if(finished)finishTimer+=dt;
        if(IsKeyPressed(KEY_ENTER)&& (paused||finished)){resetRace();paused=false;}
        auto ps=sampleTrack(*track,player.u);Vector3 pp=carPosition(*track,player);Vector3 follow=Vector3Scale(ps.t,-17);follow.y=8.5f;cam.target=Vector3Add(pp,{0,1.0f,0});cam.position=Vector3Add(pp,follow);
        BeginDrawing();ClearBackground(Color{120,178,215,255});BeginMode3D(cam);
        Color terrain=selectedTrack==0||selectedTrack==7?Color{36,132,139,255}:selectedTrack==1?Color{49,111,52,255}:selectedTrack==3?Color{54,28,25,255}:selectedTrack==6?Color{17,20,42,255}:selectedTrack==4?Color{76,119,83,255}:Color{151,112,69,255};
        drawTrack(*track,terrain,selectedTrack==6?MAGENTA:RED);
        for(int i=0;i<22;i++)if(!pickups[i].taken){Car c;c.u=pickups[i].u;c.lane=pickups[i].lane;Vector3 p=carPosition(*track,c);DrawCylinder({p.x,p.y+.55f,p.z},.38f,.38f,.16f,12,GOLD);DrawCylinderWires({p.x,p.y+.55f,p.z},.38f,.38f,.16f,12,WHITE);}
        for(auto&r:rivals)drawCar(*track,r);drawCar(*track,player);EndMode3D();
        DrawRectangle(12,12,270,92,Fade(BLACK,.62f));DrawText("BUGGY RUSH  |  C++",24,22,21,WHITE);DrawText(TextFormat("VITESSE  %03d km/h",(int)(player.speed*3.6f)),24,51,22,GOLD);DrawText(TextFormat("TOUR %d/3   PIECES %d",std::min(lap,3),player.coins),24,79,17,WHITE);
        DrawRectangle(sw/2-100,12,200,44,Fade(BLACK,.55f));DrawText(TextFormat("%02d:%05.2f",(int)(raceTime/60),fmod(raceTime,60)),sw/2-72,21,22,WHITE);
        DrawText(track->name,18,sh-34,20,WHITE);
        int position=1; for(const auto &r:rivals) if(r.u>player.u && (r.u-player.u)<.5f) position++;
        DrawText(TextFormat("POSITION %d/6",position),sw-190,20,20,WHITE);
        // Mobile controls remain visible as large touch targets.
        drawButton({18,sh-112,78,78},"<",DARKBLUE);drawButton({106,sh-112,78,78},">",DARKBLUE);drawButton({sw-112,sh-112,94,78},"GAZ",DARKGREEN);drawButton({sw-220,sh-105,88,65},"TURBO",ORANGE);drawButton({sw-112,sh-202,94,70},"FREIN",MAROON);
        if(paused){DrawRectangle(0,0,sw,sh,Fade(BLACK,.62f));DrawText("PAUSE",sw/2-75,sh/2-40,42,WHITE);DrawText("P ou ECHAP pour reprendre",sw/2-150,sh/2+15,20,LIGHTGRAY);}
        if(finished){DrawRectangle(0,0,sw,sh,Fade(BLACK,.68f));DrawText("COURSE TERMINEE !",sw/2-210,sh/2-65,40,GOLD);DrawText(TextFormat("Pieces ramassees : %d",player.coins),sw/2-130,sh/2-10,22,WHITE);DrawText("ENTREE pour recommencer",sw/2-150,sh/2+40,20,LIGHTGRAY);}
        EndDrawing();
    }
    CloseWindow();return 0;
}
