# Buggy Rush Turbo — portage C++ natif (prototype en cours)

Réécriture native en C++ avec Raylib 5.5. Le HTML original sert de référence ; il n'est pas embarqué dans l'application et aucun WebView n'est utilisé.

## Déjà présent
- Scène 3D et huit tracés de base (formes encore simplifiées).
- Voiture du joueur et cinq adversaires IA.
- Accélération, freinage, direction, dérapage simple et turbo.
- Pièces à ramasser, tours, chronomètre, menu et pause.
- Commandes tactiles et clavier pour les tests desktop.
- Projet Android NativeActivity et workflow GitHub Actions pour produire un APK debug.

## Compilation Android
Le workflow `.github/workflows/android-apk.yml` compile dans GitHub Actions. Dans le dépôt GitHub, ouvrir **Actions → Build native Android APK → Run workflow**. Une fois terminé, télécharger l'artefact `BuggyRush-debug-apk`.

## État réel
Ce n'est pas encore la reproduction complète du jeu HTML. Les modes, le garage, les effets, les sons, les circuits fidèles et les tests sur téléphone restent à réaliser. La compilation Android n'a pas encore été exécutée ici : aucun APK testé n'est inclus.
