# Buggy Rush v131 — Android APK project

The uploaded `Buggy_Rush_Turbo_v131.html` is copied unchanged to `app/src/main/assets/index.html`.
The Android WebView wrapper displays the original HTML game in fullscreen landscape. This build has a distinct application ID so it can be installed alongside the previous Buggy Rush app, and it includes a new custom launcher icon.

Build with `gradle assembleDebug` or use the repository's GitHub Actions workflow.
