BUGGY RUSH : TURBO EDITION
Portage natif C++ / Raylib — édition de reproduction étendue

BUT DU PORTAGE
Ce projet est une réécriture C++ du jeu HTML fourni. Ce n'est pas un convertisseur
automatique : le rendu Three.js et la logique JavaScript ont été reconstruits en
C++ avec Raylib. Les tracés des huit circuits proviennent du jeu d'origine.

CONTENU REPRIS / RECONSTRUIT
- 8 circuits : Plage Paradis, Jungle Perdue, Canyon Doré, Volcan en Feu,
  Col Alpin, Canyon Rouge, Néon Nocturne et Lagon Tropical.
- Piste 3D, bordures, ligne d'arrivée, arche, barrières et décors thématiques
  générés selon le circuit.
- Kart joueur orienté selon la piste, concurrents IA, collisions et ralentissement.
- Accélération, freinage, direction, dérapage, mini-turbo et jauge de turbo.
- Objets : turbo, missile (ralentit un rival) et bouclier.
- Caisses d'objets, pièces à ramasser et tapis turbo.
- Six modes : Course rapide, Championnat, Contre-la-montre avec fantôme local,
  Élimination, Chasse aux pièces et Entraînement.
- Championnats : Coupe Soleil, Coupe Nuit, Coupe Mixte et Grand Prix.
- Quatre classes de kart, huit couleurs, nom du pilote, quatre difficultés.
- Caméras proche / standard / aérienne, mini-carte, lignes de vitesse,
  sens de circuit inversé et options d'objets / rattrapage IA.
- Écran titre, garage, options, statistiques, pause et résultats.
- Sauvegarde locale des réglages, statistiques et meilleur tour.
- Commandes clavier et commandes tactiles par zones de l'écran.

COMMANDES
- Flèches ou WASD : diriger, accélérer et freiner.
- Espace ou Maj : maintenir pour déraper.
- E ou X : turbo (consomme la jauge).
- F ou Entrée : utiliser l'objet.
- R : recommencer / replacer selon l'écran.
- C : changer de caméra.
- P : pause.
- Échap : revenir au menu.
- Menu : souris/tactile ; touches 1 à 8 pour choisir un circuit.
- Sur écran tactile : toucher la moitié gauche pour diriger ; la partie droite
  sert à accélérer, freiner, déraper ou activer le turbo selon la hauteur du toucher.
  La zone supérieure droite permet d'utiliser l'objet.

COMPILATION PC
Prérequis : CMake 3.16+, compilateur C++17 et connexion Internet au premier build.
Raylib 5.5 est récupéré automatiquement par CMake.

Linux / macOS :
  cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
  cmake --build build --config Release
  ./build/BuggyRush

Windows (Visual Studio) :
  cmake -S . -B build
  cmake --build build --config Release
  puis lancer build/Release/BuggyRush.exe

FICHIERS DE SAUVEGARDE
Le jeu crée buggy_rush_save.txt et buggy_ghost_<numéro_circuit>.txt dans le
répertoire de lancement. Ils conservent les statistiques, réglages et fantômes.

LIMITES CONNUES / FIDÉLITÉ
Le gameplay principal et les systèmes listés ci-dessus sont réimplémentés, mais
le résultat n'est pas un clone pixel par pixel du rendu Three.js original.
Les modèles, textures, éclairages, effets de post-traitement, animations détaillées,
ambiance sonore et musique du HTML ne sont pas transférés à l'identique : les
éléments 3D sont reconstruits avec les primitives Raylib. Les adversaires IA et
la physique sont des réimplémentations simplifiées, pas une traduction ligne à
ligne du moteur JavaScript d'origine.

ANDROID / APK
Le code est en C++ et Raylib, mais ce ZIP ne contient pas encore d'APK compilé.
Pour fabriquer un APK, il faut une chaîne Android SDK + NDK + CMake et un projet
Gradle/Activity configuré pour Raylib Android. Cette machine de préparation ne
possède pas cette chaîne Android ; aucun APK n'est donc annoncé comme généré.

PROJET ANDROID FOURNI
Le dossier android/ contient maintenant un projet Android Gradle + CMake
configuré pour NativeActivity, paysage, API minimale 26 et ABI ARM64/ARMv7.
Pour compiler sur un ordinateur équipé d'Android Studio, du SDK Android, du NDK
et de CMake 3.22.1 : ouvrir le dossier android/ dans Android Studio puis lancer
Build > Build APK(s). Le premier build télécharge Raylib 5.5 via CMake, donc une
connexion Internet est nécessaire. Le script build_android.sh (Linux/macOS) ou
build_android_windows.bat (Windows) lance aussi Gradle si celui-ci est installé.
L'APK debug attendu sera dans android/app/build/outputs/apk/debug/.

IMPORTANT : le projet Android est configuré, mais aucun APK précompilé n'est
inclus car l'environnement de préparation ne possède ni Android SDK ni NDK.
Le projet doit être compilé sur un ordinateur disposant de ces composants.
