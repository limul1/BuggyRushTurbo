# Buggy Rush : Turbo Édition — portage natif

## Livrable
- Réécriture C++17 avec Raylib 5.5.
- Huit tracés repris depuis les points du jeu HTML et interpolés par spline.
- Circuits 3D procéduraux, karts, IA, collisions, objets, pièces, turbo, dérapage,
  modes, championnats, options, statistiques, sauvegardes et fantôme local.
- Contrôles clavier/souris et zones tactiles.
- Projet Android Gradle + CMake configuré pour NativeActivity en paysage.

## Compilation PC
Prérequis : CMake 3.22+, compilateur C++17 et connexion Internet au premier build.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

## Compilation Android
Ouvrir `android/` dans Android Studio avec SDK 35, NDK installé et CMake 3.22.1.
Lancer **Build > Build APK(s)**. Le premier build télécharge Raylib 5.5.
L'APK debug sera créé dans `android/app/build/outputs/apk/debug/`.

## Limites de fidélité
Il s'agit d'une réimplémentation fonctionnelle, pas d'une conversion automatique
ni d'un clone pixel par pixel. Le rendu Three.js, les shaders, textures procédurales,
modèles détaillés, animations, musique et effets audio du HTML ne sont pas repris
à l'identique. Les modèles et décors 3D sont reconstruits avec les primitives
Raylib ; la physique et l'IA sont des adaptations simplifiées.

## État de l'APK
Le projet Android est préparé, mais aucun APK précompilé n'est inclus : la machine
de préparation ne dispose pas de l'Android SDK/NDK ni des outils de signature.
Le dossier Android est fourni pour effectuer ce build sur une machine configurée.
