# Générer Buggy Rush APK depuis un téléphone Android

Ce projet contient un workflow GitHub Actions qui compile l'APK dans le cloud. Il n'est pas nécessaire d'installer Android Studio, le SDK ou le NDK sur le téléphone.

## Procédure depuis le téléphone

1. Crée un compte ou connecte-toi sur https://github.com.
2. Dans GitHub, crée un dépôt public vide nommé `BuggyRushTurbo` (ne coche pas README, licence ou .gitignore).
3. Ouvre le dépôt, choisis **Add file > Upload files** et téléverse le contenu du dossier `BuggyRush_CPP` (pas le dossier parent). Vérifie que `.github/workflows/android-apk.yml` est bien présent. Sur mobile, l'affichage des fichiers cachés peut nécessiter l'activation de « afficher les fichiers cachés » dans le gestionnaire de fichiers.
4. Valide avec **Commit changes**. Le workflow démarre automatiquement après le premier envoi sur `main` ou `master`.
5. Ouvre l'onglet **Actions**, sélectionne **Build Buggy Rush APK**, puis le dernier lancement.
6. Quand le lancement est terminé avec une coche verte, descends jusqu'à **Artifacts** et télécharge `BuggyRush-APK-debug`.
7. Décompresse l'archive téléchargée : elle contient `app-debug.apk`. Ouvre ce fichier pour installer le jeu. Android peut demander d'autoriser l'installation pour ton navigateur ou ton gestionnaire de fichiers.

## Si la compilation échoue

Ouvre le lancement dans Actions et consulte **Build APK > Compiler l'APK debug**. Copie ici le message d'erreur complet (ou une capture d'écran) : je pourrai corriger le projet.

## À savoir

- L'APK généré par ce workflow est une version **debug**, non publiée sur Play Store.
- La première compilation télécharge Raylib 5.5 depuis GitHub et peut prendre plusieurs minutes.
- Le workflow compile `arm64-v8a` et `armeabi-v7a` selon les ABI déclarées dans `android/app/build.gradle`.
- L'APK n'est pas encore généré à la création de cette archive : il le sera par GitHub Actions après l'envoi du projet.
