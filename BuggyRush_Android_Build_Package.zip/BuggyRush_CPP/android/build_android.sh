#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle introuvable. Installe Android Studio/Gradle puis relance ce script." >&2
  exit 2
fi
if [ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]; then
  echo "ANDROID_HOME ou ANDROID_SDK_ROOT n'est pas défini." >&2
  exit 2
fi
gradle --no-daemon :app:assembleDebug
echo "APK : android/app/build/outputs/apk/debug/app-debug.apk"
