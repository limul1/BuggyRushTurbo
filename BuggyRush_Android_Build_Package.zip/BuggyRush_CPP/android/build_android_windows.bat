@echo off
cd /d "%~dp0"
where gradle >nul 2>nul || (echo Gradle introuvable. Installe Android Studio/Gradle. & exit /b 2)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ANDROID_HOME ou ANDROID_SDK_ROOT n'est pas defini. & exit /b 2)
gradle --no-daemon :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK : app\build\outputs\apk\debug\app-debug.apk
